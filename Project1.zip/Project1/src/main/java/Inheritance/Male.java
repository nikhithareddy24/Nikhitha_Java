package main.java.Inheritance;

public class Male extends Person
{
    public void walk()
    {
        super.walk();
        System.out.println("Inheritance.Male walks differently");
    }
}

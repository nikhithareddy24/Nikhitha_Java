package main.java.Inheritance;

import main.java.Inheritance.Male;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
        Male m = new Male();
        m.walk();

    }
}
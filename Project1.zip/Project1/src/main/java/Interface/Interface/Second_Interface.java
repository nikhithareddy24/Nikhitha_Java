package main.java.Interface.Interface;

interface Second_Interface
{
    public int Perimeter(int a, int b, int c);

}

package main.java.Interface.Interface;

interface First_Interface
{
    public double Area(int b,int h);
}

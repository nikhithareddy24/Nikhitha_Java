package main.java.Interface.InstanceVariables;

public class Vehicle
{
    int milage;

}
